
package MovingCircle;

import javafx.animation.PathTransition;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Ellipse;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;
import javafx.util.Duration;

public class MovingCircle extends Application {
   
    @Override
    public void start(Stage primaryStage) {
        Pane pane = new Pane();
        
        
        Circle circle = new Circle(25,20,10);
        circle.setFill(Color.RED);
        circle.setStroke(Color.BLACK);
        
        Ellipse ellipse = new Ellipse();
            ellipse.setCenterX(250);
            ellipse.setCenterY(250);
            ellipse.setRadiusX(420/2);
            ellipse.setRadiusY(300/2);
            ellipse.setFill(Color.WHITE);
            ellipse.setStroke(Color.BLACK);
        
        pane.getChildren().add(ellipse);
        pane.getChildren().add(circle);
        
        PathTransition pt = new PathTransition();
        pt.setDuration(Duration.millis(10000));
        pt.setPath(ellipse);
        pt.setNode(circle);
        pt.setOrientation(PathTransition.OrientationType.ORTHOGONAL_TO_TANGENT);
        pt.setCycleCount(Timeline.INDEFINITE);
        pt.setAutoReverse(false);
        pt.play();
        
        Scene scene = new Scene(pane,500,500);
        primaryStage.setTitle("Moving Circle");
        primaryStage.setScene(scene);
        primaryStage.show();
    }
   
    public static void main(String[] args) {
        launch(args);
    }
    
}
